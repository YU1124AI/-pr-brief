import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'trend catch | 毎朝のPRインテリジェンス',
  description: '毎朝9:00更新 — PR TIMES・PR EDGE・Yahoo!ニュース・朝日新聞・宣伝会議・Xトレンドを集約したダッシュボード',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  )
}
